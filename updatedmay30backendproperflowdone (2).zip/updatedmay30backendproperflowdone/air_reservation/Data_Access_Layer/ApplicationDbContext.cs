﻿using air_reservation.Data_Access_Layer.DataSeeding;
using air_reservation.Models.Flight_Model_;
using air_reservation.Models.Passenger_Model_;
using air_reservation.Models.Payment_Model_;
using air_reservation.Models.Registration_Model_;
using air_reservation.Models.Reservation_Model_;
using air_reservation.Models.Users_Model_;
using Microsoft.EntityFrameworkCore;

namespace air_reservation.Data_Access_Layer
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<User> Users { get; set; }
        public DbSet<LoginModel> LoginLogs { get; set; }
        public DbSet<RegisterModel> RegistrationLogs { get; set; }
        public DbSet<Flight> Flights { get; set; }
        public DbSet<Reservation> Reservations { get; set; }
        public DbSet<Passenger> Passengers { get; set; }
        public DbSet<Payment> Payments { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // User Configuration
            modelBuilder.Entity<User>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.HasIndex(e => e.Email).IsUnique();
                entity.Property(e => e.Email).IsRequired().HasMaxLength(100);
                entity.Property(e => e.FirstName).IsRequired().HasMaxLength(50);
                entity.Property(e => e.LastName).IsRequired().HasMaxLength(50);
                entity.Property(e => e.Role).HasDefaultValue(UserRole.User);
            });

            // Flight Configuration
            modelBuilder.Entity<Flight>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.FlightNumber).IsRequired().HasMaxLength(20);
                entity.Property(e => e.Airline).IsRequired().HasMaxLength(50);
                entity.Property(e => e.Origin).IsRequired().HasMaxLength(50);
                entity.Property(e => e.Destination).IsRequired().HasMaxLength(50);
                entity.Property(e => e.EconomyPrice).HasColumnType("decimal(10,2)");
                entity.Property(e => e.BusinessPrice).HasColumnType("decimal(10,2)");
            });

            // Reservation Configuration
            modelBuilder.Entity<Reservation>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.BookingReference).IsRequired().HasMaxLength(20);
                entity.Property(e => e.TotalAmount).HasColumnType("decimal(10,2)");

                entity.HasOne(e => e.User)
                    .WithMany(u => u.Reservations)
                    .HasForeignKey(e => e.UserId)
                    .OnDelete(DeleteBehavior.Restrict);

                entity.HasOne(e => e.Flight)
                    .WithMany(f => f.Reservations)
                    .HasForeignKey(e => e.FlightId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            // Payment Configuration
            modelBuilder.Entity<Payment>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Amount).HasColumnType("decimal(10,2)");
                entity.Property(e => e.TransactionId).HasMaxLength(100);

                entity.HasOne(e => e.Reservation)
                    .WithOne(r => r.Payment)
                    .HasForeignKey<Payment>(e => e.ReservationId)
                    .OnDelete(DeleteBehavior.Cascade);
            });

            // Seed Initial Data
            SeedData(modelBuilder);

            // Call Flight Seeding
            FlightSeedData.Seed(modelBuilder);
        }

        private void SeedData(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<User>().HasData(
                new User
                {
                    Id = 1,
                    Email = "aster@gmail.com",
                    Password = BCrypt.Net.BCrypt.HashPassword("aster07"),
                    FirstName = "System",
                    LastName = "Administrator",
                    PhoneNumber = "+1234567890",
                    Role = UserRole.Admin,
                    CreatedAt = DateTime.UtcNow
                }
            );
        }
    }
}
