﻿using air_reservation.Models.Flight_Model_;
using Microsoft.EntityFrameworkCore;

namespace air_reservation.Data_Access_Layer.DataSeeding
{
    public static class FlightSeedData
    {
        public static void Seed(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Flight>().HasData(
                // **International Flights**
                new Flight
                {
                    Id = 1,
                    FlightNumber = "AA101",
                    Airline = "American Airlines",
                    Origin = "New York",
                    Destination = "Los Angeles",
                    DepartureDateTime = DateTime.UtcNow.AddDays(7),
                    ArrivalDateTime = DateTime.UtcNow.AddDays(7).AddHours(6),
                    TotalEconomySeats = 150,
                    TotalBusinessSeats = 30,
                    AvailableEconomySeats = 150,
                    AvailableBusinessSeats = 30,
                    EconomyPrice = 299.99m,
                    BusinessPrice = 899.99m,
                    Aircraft = "Boeing 737",
                    Status = FlightStatus.Scheduled
                },
new Flight
{
    Id = 2,
    FlightNumber = "DL202",
    Airline = "Delta Airlines",
    Origin = "Chicago",
    Destination = "Miami",
    DepartureDateTime = DateTime.UtcNow.AddDays(8),
    ArrivalDateTime = DateTime.UtcNow.AddDays(8).AddHours(3),
    TotalEconomySeats = 180,
    TotalBusinessSeats = 40,
    AvailableEconomySeats = 180,
    AvailableBusinessSeats = 40,
    EconomyPrice = 249.99m,
    BusinessPrice = 699.99m,
    Aircraft = "Airbus A320",
    Status = FlightStatus.Scheduled
},
new Flight
{
    Id = 3,
    FlightNumber = "UA303",
    Airline = "United Airlines",
    Origin = "San Francisco",
    Destination = "Seattle",
    DepartureDateTime = DateTime.UtcNow.AddDays(9),
    ArrivalDateTime = DateTime.UtcNow.AddDays(9).AddHours(2),
    TotalEconomySeats = 140,
    TotalBusinessSeats = 35,
    AvailableEconomySeats = 140,
    AvailableBusinessSeats = 35,
    EconomyPrice = 199.99m,
    BusinessPrice = 599.99m,
    Aircraft = "Boeing 757",
    Status = FlightStatus.Scheduled
},
new Flight
{
    Id = 4,
    FlightNumber = "BA404",
    Airline = "British Airways",
    Origin = "London",
    Destination = "Paris",
    DepartureDateTime = DateTime.UtcNow.AddDays(7),
    ArrivalDateTime = DateTime.UtcNow.AddDays(7).AddHours(1),
    TotalEconomySeats = 170,
    TotalBusinessSeats = 25,
    AvailableEconomySeats = 170,
    AvailableBusinessSeats = 25,
    EconomyPrice = 149.99m,
    BusinessPrice = 499.99m,
    Aircraft = "Airbus A319",
    Status = FlightStatus.Scheduled
},
new Flight
{
    Id = 5,
    FlightNumber = "AF505",
    Airline = "Air France",
    Origin = "Paris",
    Destination = "Berlin",
    DepartureDateTime = DateTime.UtcNow.AddDays(6),
    ArrivalDateTime = DateTime.UtcNow.AddDays(6).AddHours(2),
    TotalEconomySeats = 165,
    TotalBusinessSeats = 30,
    AvailableEconomySeats = 165,
    AvailableBusinessSeats = 30,
    EconomyPrice = 179.99m,
    BusinessPrice = 579.99m,
    Aircraft = "Airbus A321",
    Status = FlightStatus.Scheduled
},

               // **Round Trips**
               new Flight
               {
                   Id = 6,
                   FlightNumber = "AA606",
                   Airline = "American Airlines",
                   Origin = "Los Angeles",
                   Destination = "New York",
                   DepartureDateTime = DateTime.UtcNow.AddDays(9),
                   ArrivalDateTime = DateTime.UtcNow.AddDays(9).AddHours(6),
                   TotalEconomySeats = 150,
                   TotalBusinessSeats = 30,
                   AvailableEconomySeats = 150,
                   AvailableBusinessSeats = 30,
                   EconomyPrice = 299.99m,
                   BusinessPrice = 899.99m,
                   Aircraft = "Boeing 737",
                   Status = FlightStatus.Scheduled
               },
new Flight
{
    Id = 7,
    FlightNumber = "DL707",
    Airline = "Delta Airlines",
    Origin = "Miami",
    Destination = "Chicago",
    DepartureDateTime = DateTime.UtcNow.AddDays(10),
    ArrivalDateTime = DateTime.UtcNow.AddDays(10).AddHours(3),
    TotalEconomySeats = 180,
    TotalBusinessSeats = 40,
    AvailableEconomySeats = 180,
    AvailableBusinessSeats = 40,
    EconomyPrice = 249.99m,
    BusinessPrice = 699.99m,
    Aircraft = "Airbus A320",
    Status = FlightStatus.Scheduled
},
new Flight
{
    Id = 8,
    FlightNumber = "UA808",
    Airline = "United Airlines",
    Origin = "Seattle",
    Destination = "San Francisco",
    DepartureDateTime = DateTime.UtcNow.AddDays(11),
    ArrivalDateTime = DateTime.UtcNow.AddDays(11).AddHours(2),
    TotalEconomySeats = 140,
    TotalBusinessSeats = 35,
    AvailableEconomySeats = 140,
    AvailableBusinessSeats = 35,
    EconomyPrice = 199.99m,
    BusinessPrice = 599.99m,
    Aircraft = "Boeing 757",
    Status = FlightStatus.Scheduled
},
new Flight
{
    Id = 9,
    FlightNumber = "BA909",
    Airline = "British Airways",
    Origin = "Paris",
    Destination = "London",
    DepartureDateTime = DateTime.UtcNow.AddDays(8),
    ArrivalDateTime = DateTime.UtcNow.AddDays(8).AddHours(1),
    TotalEconomySeats = 170,
    TotalBusinessSeats = 25,
    AvailableEconomySeats = 170,
    AvailableBusinessSeats = 25,
    EconomyPrice = 149.99m,
    BusinessPrice = 499.99m,
    Aircraft = "Airbus A319",
    Status = FlightStatus.Scheduled
},
new Flight
{
    Id = 10,
    FlightNumber = "AF1010",
    Airline = "Air France",
    Origin = "Berlin",
    Destination = "Paris",
    DepartureDateTime = DateTime.UtcNow.AddDays(7),
    ArrivalDateTime = DateTime.UtcNow.AddDays(7).AddHours(2),
    TotalEconomySeats = 165,
    TotalBusinessSeats = 30,
    AvailableEconomySeats = 165,
    AvailableBusinessSeats = 30,
    EconomyPrice = 179.99m,
    BusinessPrice = 579.99m,
    Aircraft = "Airbus A321",
    Status = FlightStatus.Scheduled
},

                // **Long-Haul International Flights**
                new Flight
                {
                    Id = 11,
                    FlightNumber = "EK1111",
                    Airline = "Emirates",
                    Origin = "Dubai",
                    Destination = "Singapore",
                    DepartureDateTime = DateTime.UtcNow.AddDays(10),
                    ArrivalDateTime = DateTime.UtcNow.AddDays(10).AddHours(7),
                    TotalEconomySeats = 200,
                    TotalBusinessSeats = 50,
                    AvailableEconomySeats = 200,
                    AvailableBusinessSeats = 50,
                    EconomyPrice = 399.99m,
                    BusinessPrice = 999.99m,
                    Aircraft = "Boeing 777",
                    Status = FlightStatus.Scheduled
                },
new Flight
{
    Id = 12,
    FlightNumber = "LH1212",
    Airline = "Lufthansa",
    Origin = "Frankfurt",
    Destination = "Madrid",
    DepartureDateTime = DateTime.UtcNow.AddDays(9),
    ArrivalDateTime = DateTime.UtcNow.AddDays(9).AddHours(3),
    TotalEconomySeats = 180,
    TotalBusinessSeats = 40,
    AvailableEconomySeats = 180,
    AvailableBusinessSeats = 40,
    EconomyPrice = 189.99m,
    BusinessPrice = 549.99m,
    Aircraft = "Airbus A350",
    Status = FlightStatus.Scheduled
},
new Flight
{
    Id = 13,
    FlightNumber = "SQ1313",
    Airline = "Singapore Airlines",
    Origin = "Singapore",
    Destination = "Bangkok",
    DepartureDateTime = DateTime.UtcNow.AddDays(11),
    ArrivalDateTime = DateTime.UtcNow.AddDays(11).AddHours(2),
    TotalEconomySeats = 190,
    TotalBusinessSeats = 45,
    AvailableEconomySeats = 190,
    AvailableBusinessSeats = 45,
    EconomyPrice = 219.99m,
    BusinessPrice = 649.99m,
    Aircraft = "Boeing 787 Dreamliner",
    Status = FlightStatus.Scheduled
},
new Flight
{
    Id = 14,
    FlightNumber = "CX1414",
    Airline = "Cathay Pacific",
    Origin = "Hong Kong",
    Destination = "Tokyo",
    DepartureDateTime = DateTime.UtcNow.AddDays(8),
    ArrivalDateTime = DateTime.UtcNow.AddDays(8).AddHours(4),
    TotalEconomySeats = 175,
    TotalBusinessSeats = 38,
    AvailableEconomySeats = 175,
    AvailableBusinessSeats = 38,
    EconomyPrice = 259.99m,
    BusinessPrice = 799.99m,
    Aircraft = "Airbus A330",
    Status = FlightStatus.Scheduled
},
new Flight
{
    Id = 15,
    FlightNumber = "QR1515",
    Airline = "Qatar Airways",
    Origin = "Doha",
    Destination = "London",
    DepartureDateTime = DateTime.UtcNow.AddDays(12),
    ArrivalDateTime = DateTime.UtcNow.AddDays(12).AddHours(8),
    TotalEconomySeats = 210,
    TotalBusinessSeats = 60,
    AvailableEconomySeats = 210,
    AvailableBusinessSeats = 60,
    EconomyPrice = 449.99m,
    BusinessPrice = 1099.99m,
    Aircraft = "Boeing 787-9",
    Status = FlightStatus.Scheduled
},

                // **Domestic Flights (India)**
                new Flight
                {
                    Id = 26,
                    FlightNumber = "AI2626",
                    Airline = "Air India",
                    Origin = "Delhi",
                    Destination = "Mumbai",
                    DepartureDateTime = DateTime.UtcNow.AddDays(5),
                    ArrivalDateTime = DateTime.UtcNow.AddDays(5).AddHours(2),
                    TotalEconomySeats = 180,
                    TotalBusinessSeats = 40,
                    AvailableEconomySeats = 180,
                    AvailableBusinessSeats = 40,
                    EconomyPrice = 129.99m,
                    BusinessPrice = 349.99m,
                    Aircraft = "Airbus A320",
                    Status = FlightStatus.Scheduled
                },
new Flight
{
    Id = 27,
    FlightNumber = "SG2727",
    Airline = "SpiceJet",
    Origin = "Mumbai",
    Destination = "Bangalore",
    DepartureDateTime = DateTime.UtcNow.AddDays(6),
    ArrivalDateTime = DateTime.UtcNow.AddDays(6).AddHours(2),
    TotalEconomySeats = 160,
    TotalBusinessSeats = 35,
    AvailableEconomySeats = 160,
    AvailableBusinessSeats = 35,
    EconomyPrice = 119.99m,
    BusinessPrice = 329.99m,
    Aircraft = "Boeing 737",
    Status = FlightStatus.Scheduled
},
new Flight
{
    Id = 28,
    FlightNumber = "6E2828",
    Airline = "IndiGo",
    Origin = "Bangalore",
    Destination = "Hyderabad",
    DepartureDateTime = DateTime.UtcNow.AddDays(7),
    ArrivalDateTime = DateTime.UtcNow.AddDays(7).AddHours(1),
    TotalEconomySeats = 150,
    TotalBusinessSeats = 30,
    AvailableEconomySeats = 150,
    AvailableBusinessSeats = 30,
    EconomyPrice = 99.99m,
    BusinessPrice = 289.99m,
    Aircraft = "ATR 72",
    Status = FlightStatus.Scheduled
},
new Flight
{
    Id = 29,
    FlightNumber = "Vistara2929",
    Airline = "Vistara",
    Origin = "Hyderabad",
    Destination = "Chennai",
    DepartureDateTime = DateTime.UtcNow.AddDays(8),
    ArrivalDateTime = DateTime.UtcNow.AddDays(8).AddHours(1),
    TotalEconomySeats = 170,
    TotalBusinessSeats = 38,
    AvailableEconomySeats = 170,
    AvailableBusinessSeats = 38,
    EconomyPrice = 109.99m,
    BusinessPrice = 299.99m,
    Aircraft = "Airbus A321",
    Status = FlightStatus.Scheduled
},
new Flight
{
    Id = 30,
    FlightNumber = "AI3030",
    Airline = "Air India",
    Origin = "Chennai",
    Destination = "Kolkata",
    DepartureDateTime = DateTime.UtcNow.AddDays(9),
    ArrivalDateTime = DateTime.UtcNow.AddDays(9).AddHours(3),
    TotalEconomySeats = 175,
    TotalBusinessSeats = 40,
    AvailableEconomySeats = 175,
    AvailableBusinessSeats = 40,
    EconomyPrice = 139.99m,
    BusinessPrice = 359.99m,
    Aircraft = "Boeing 737 MAX",
    Status = FlightStatus.Scheduled
},
new Flight
{
    Id = 31,
    FlightNumber = "SG3131",
    Airline = "SpiceJet",
    Origin = "Kolkata",
    Destination = "Delhi",
    DepartureDateTime = DateTime.UtcNow.AddDays(10),
    ArrivalDateTime = DateTime.UtcNow.AddDays(10).AddHours(2),
    TotalEconomySeats = 160,
    TotalBusinessSeats = 35,
    AvailableEconomySeats = 160,
    AvailableBusinessSeats = 35,
    EconomyPrice = 149.99m,
    BusinessPrice = 369.99m,
    Aircraft = "Airbus A320",
    Status = FlightStatus.Scheduled
},
new Flight
{
    Id = 32,
    FlightNumber = "6E3232",
    Airline = "IndiGo",
    Origin = "Delhi",
    Destination = "Goa",
    DepartureDateTime = DateTime.UtcNow.AddDays(11),
    ArrivalDateTime = DateTime.UtcNow.AddDays(11).AddHours(2),
    TotalEconomySeats = 180,
    TotalBusinessSeats = 40,
    AvailableEconomySeats = 180,
    AvailableBusinessSeats = 40,
    EconomyPrice = 159.99m,
    BusinessPrice = 399.99m,
    Aircraft = "Airbus A321",
    Status = FlightStatus.Scheduled
},
new Flight
{
    Id = 33,
    FlightNumber = "Vistara3333",
    Airline = "Vistara",
    Origin = "Goa",
    Destination = "Pune",
    DepartureDateTime = DateTime.UtcNow.AddDays(12),
    ArrivalDateTime = DateTime.UtcNow.AddDays(12).AddHours(1),
    TotalEconomySeats = 150,
    TotalBusinessSeats = 30,
    AvailableEconomySeats = 150,
    AvailableBusinessSeats = 30,
    EconomyPrice = 109.99m,
    BusinessPrice = 299.99m,
    Aircraft = "ATR 72",
    Status = FlightStatus.Scheduled
},
new Flight
{
    Id = 34,
    FlightNumber = "AI3434",
    Airline = "Air India",
    Origin = "Pune",
    Destination = "Ahmedabad",
    DepartureDateTime = DateTime.UtcNow.AddDays(13),
    ArrivalDateTime = DateTime.UtcNow.AddDays(13).AddHours(2),
    TotalEconomySeats = 160,
    TotalBusinessSeats = 35,
    AvailableEconomySeats = 160,
    AvailableBusinessSeats = 35,
    EconomyPrice = 119.99m,
    BusinessPrice = 329.99m,
    Aircraft = "Boeing 737",
    Status = FlightStatus.Scheduled
},
new Flight
{
    Id = 35,
    FlightNumber = "SG3535",
    Airline = "SpiceJet",
    Origin = "Ahmedabad",
    Destination = "Jaipur",
    DepartureDateTime = DateTime.UtcNow.AddDays(14),
    ArrivalDateTime = DateTime.UtcNow.AddDays(14).AddHours(1),
    TotalEconomySeats = 170,
    TotalBusinessSeats = 38,
    AvailableEconomySeats = 170,
    AvailableBusinessSeats = 38,
    EconomyPrice = 129.99m,
    BusinessPrice = 339.99m,
    Aircraft = "Airbus A320",
    Status = FlightStatus.Scheduled
}
            );
        }

    }
}
