﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace air_reservation.Migrations
{
    /// <inheritdoc />
    public partial class init : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Flights",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FlightNumber = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    Airline = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Origin = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Destination = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    DepartureDateTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ArrivalDateTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    TotalEconomySeats = table.Column<int>(type: "int", nullable: false),
                    TotalBusinessSeats = table.Column<int>(type: "int", nullable: false),
                    AvailableEconomySeats = table.Column<int>(type: "int", nullable: false),
                    AvailableBusinessSeats = table.Column<int>(type: "int", nullable: false),
                    EconomyPrice = table.Column<decimal>(type: "decimal(10,2)", nullable: false),
                    BusinessPrice = table.Column<decimal>(type: "decimal(10,2)", nullable: false),
                    Aircraft = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Status = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Flights", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "LoginLogs",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Password = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    LoginTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IpAddress = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UserAgent = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    IsSuccessful = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LoginLogs", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "RegistrationLogs",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Password = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    FirstName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    LastName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PhoneNumber = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Role = table.Column<int>(type: "int", nullable: false),
                    RegistrationDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IpAddress = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    IsEmailVerified = table.Column<bool>(type: "bit", nullable: false),
                    VerificationToken = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RegistrationLogs", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Users",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Email = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Password = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    FirstName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    LastName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    PhoneNumber = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Role = table.Column<int>(type: "int", nullable: false, defaultValue: 0),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Users", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Reservations",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    BookingReference = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    UserId = table.Column<int>(type: "int", nullable: false),
                    FlightId = table.Column<int>(type: "int", nullable: false),
                    BookingDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Status = table.Column<int>(type: "int", nullable: false),
                    TotalAmount = table.Column<decimal>(type: "decimal(10,2)", nullable: false),
                    ExpiresAt = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Reservations", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Reservations_Flights_FlightId",
                        column: x => x.FlightId,
                        principalTable: "Flights",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Reservations_Users_UserId",
                        column: x => x.UserId,
                        principalTable: "Users",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Passengers",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FirstName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    LastName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Age = table.Column<int>(type: "int", nullable: false),
                    Gender = table.Column<int>(type: "int", nullable: false),
                    SeatClass = table.Column<int>(type: "int", nullable: false),
                    SeatNumber = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ReservationId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Passengers", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Passengers_Reservations_ReservationId",
                        column: x => x.ReservationId,
                        principalTable: "Reservations",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Payments",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ReservationId = table.Column<int>(type: "int", nullable: false),
                    Amount = table.Column<decimal>(type: "decimal(10,2)", nullable: false),
                    PaymentMethod = table.Column<int>(type: "int", nullable: false),
                    Status = table.Column<int>(type: "int", nullable: false),
                    TransactionId = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    PaymentDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    PaymentGatewayResponse = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Payments", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Payments_Reservations_ReservationId",
                        column: x => x.ReservationId,
                        principalTable: "Reservations",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Flights",
                columns: new[] { "Id", "Aircraft", "Airline", "ArrivalDateTime", "AvailableBusinessSeats", "AvailableEconomySeats", "BusinessPrice", "DepartureDateTime", "Destination", "EconomyPrice", "FlightNumber", "Origin", "Status", "TotalBusinessSeats", "TotalEconomySeats" },
                values: new object[,]
                {
                    { 1, "Boeing 737", "American Airlines", new DateTime(2025, 6, 6, 14, 35, 48, 749, DateTimeKind.Utc).AddTicks(8712), 30, 150, 899.99m, new DateTime(2025, 6, 6, 8, 35, 48, 749, DateTimeKind.Utc).AddTicks(8706), "Los Angeles", 299.99m, "AA101", "New York", 0, 30, 150 },
                    { 2, "Airbus A320", "Delta Airlines", new DateTime(2025, 6, 7, 11, 35, 48, 749, DateTimeKind.Utc).AddTicks(8721), 40, 180, 699.99m, new DateTime(2025, 6, 7, 8, 35, 48, 749, DateTimeKind.Utc).AddTicks(8720), "Miami", 249.99m, "DL202", "Chicago", 0, 40, 180 },
                    { 3, "Boeing 757", "United Airlines", new DateTime(2025, 6, 8, 10, 35, 48, 749, DateTimeKind.Utc).AddTicks(8724), 35, 140, 599.99m, new DateTime(2025, 6, 8, 8, 35, 48, 749, DateTimeKind.Utc).AddTicks(8724), "Seattle", 199.99m, "UA303", "San Francisco", 0, 35, 140 },
                    { 4, "Airbus A319", "British Airways", new DateTime(2025, 6, 6, 9, 35, 48, 749, DateTimeKind.Utc).AddTicks(8727), 25, 170, 499.99m, new DateTime(2025, 6, 6, 8, 35, 48, 749, DateTimeKind.Utc).AddTicks(8727), "Paris", 149.99m, "BA404", "London", 0, 25, 170 },
                    { 5, "Airbus A321", "Air France", new DateTime(2025, 6, 5, 10, 35, 48, 749, DateTimeKind.Utc).AddTicks(8730), 30, 165, 579.99m, new DateTime(2025, 6, 5, 8, 35, 48, 749, DateTimeKind.Utc).AddTicks(8730), "Berlin", 179.99m, "AF505", "Paris", 0, 30, 165 },
                    { 6, "Boeing 737", "American Airlines", new DateTime(2025, 6, 8, 14, 35, 48, 749, DateTimeKind.Utc).AddTicks(8735), 30, 150, 899.99m, new DateTime(2025, 6, 8, 8, 35, 48, 749, DateTimeKind.Utc).AddTicks(8735), "New York", 299.99m, "AA606", "Los Angeles", 0, 30, 150 },
                    { 7, "Airbus A320", "Delta Airlines", new DateTime(2025, 6, 9, 11, 35, 48, 749, DateTimeKind.Utc).AddTicks(8738), 40, 180, 699.99m, new DateTime(2025, 6, 9, 8, 35, 48, 749, DateTimeKind.Utc).AddTicks(8737), "Chicago", 249.99m, "DL707", "Miami", 0, 40, 180 },
                    { 8, "Boeing 757", "United Airlines", new DateTime(2025, 6, 10, 10, 35, 48, 749, DateTimeKind.Utc).AddTicks(8740), 35, 140, 599.99m, new DateTime(2025, 6, 10, 8, 35, 48, 749, DateTimeKind.Utc).AddTicks(8740), "San Francisco", 199.99m, "UA808", "Seattle", 0, 35, 140 },
                    { 9, "Airbus A319", "British Airways", new DateTime(2025, 6, 7, 9, 35, 48, 749, DateTimeKind.Utc).AddTicks(8743), 25, 170, 499.99m, new DateTime(2025, 6, 7, 8, 35, 48, 749, DateTimeKind.Utc).AddTicks(8742), "London", 149.99m, "BA909", "Paris", 0, 25, 170 },
                    { 10, "Airbus A321", "Air France", new DateTime(2025, 6, 6, 10, 35, 48, 749, DateTimeKind.Utc).AddTicks(8745), 30, 165, 579.99m, new DateTime(2025, 6, 6, 8, 35, 48, 749, DateTimeKind.Utc).AddTicks(8745), "Paris", 179.99m, "AF1010", "Berlin", 0, 30, 165 },
                    { 11, "Boeing 777", "Emirates", new DateTime(2025, 6, 9, 15, 35, 48, 749, DateTimeKind.Utc).AddTicks(8749), 50, 200, 999.99m, new DateTime(2025, 6, 9, 8, 35, 48, 749, DateTimeKind.Utc).AddTicks(8748), "Singapore", 399.99m, "EK1111", "Dubai", 0, 50, 200 },
                    { 12, "Airbus A350", "Lufthansa", new DateTime(2025, 6, 8, 11, 35, 48, 749, DateTimeKind.Utc).AddTicks(8752), 40, 180, 549.99m, new DateTime(2025, 6, 8, 8, 35, 48, 749, DateTimeKind.Utc).AddTicks(8751), "Madrid", 189.99m, "LH1212", "Frankfurt", 0, 40, 180 },
                    { 13, "Boeing 787 Dreamliner", "Singapore Airlines", new DateTime(2025, 6, 10, 10, 35, 48, 749, DateTimeKind.Utc).AddTicks(8754), 45, 190, 649.99m, new DateTime(2025, 6, 10, 8, 35, 48, 749, DateTimeKind.Utc).AddTicks(8754), "Bangkok", 219.99m, "SQ1313", "Singapore", 0, 45, 190 },
                    { 14, "Airbus A330", "Cathay Pacific", new DateTime(2025, 6, 7, 12, 35, 48, 749, DateTimeKind.Utc).AddTicks(8757), 38, 175, 799.99m, new DateTime(2025, 6, 7, 8, 35, 48, 749, DateTimeKind.Utc).AddTicks(8757), "Tokyo", 259.99m, "CX1414", "Hong Kong", 0, 38, 175 },
                    { 15, "Boeing 787-9", "Qatar Airways", new DateTime(2025, 6, 11, 16, 35, 48, 749, DateTimeKind.Utc).AddTicks(8760), 60, 210, 1099.99m, new DateTime(2025, 6, 11, 8, 35, 48, 749, DateTimeKind.Utc).AddTicks(8759), "London", 449.99m, "QR1515", "Doha", 0, 60, 210 },
                    { 26, "Airbus A320", "Air India", new DateTime(2025, 6, 4, 10, 35, 48, 749, DateTimeKind.Utc).AddTicks(8762), 40, 180, 349.99m, new DateTime(2025, 6, 4, 8, 35, 48, 749, DateTimeKind.Utc).AddTicks(8762), "Mumbai", 129.99m, "AI2626", "Delhi", 0, 40, 180 },
                    { 27, "Boeing 737", "SpiceJet", new DateTime(2025, 6, 5, 10, 35, 48, 749, DateTimeKind.Utc).AddTicks(8765), 35, 160, 329.99m, new DateTime(2025, 6, 5, 8, 35, 48, 749, DateTimeKind.Utc).AddTicks(8765), "Bangalore", 119.99m, "SG2727", "Mumbai", 0, 35, 160 },
                    { 28, "ATR 72", "IndiGo", new DateTime(2025, 6, 6, 9, 35, 48, 749, DateTimeKind.Utc).AddTicks(8768), 30, 150, 289.99m, new DateTime(2025, 6, 6, 8, 35, 48, 749, DateTimeKind.Utc).AddTicks(8767), "Hyderabad", 99.99m, "6E2828", "Bangalore", 0, 30, 150 },
                    { 29, "Airbus A321", "Vistara", new DateTime(2025, 6, 7, 9, 35, 48, 749, DateTimeKind.Utc).AddTicks(8770), 38, 170, 299.99m, new DateTime(2025, 6, 7, 8, 35, 48, 749, DateTimeKind.Utc).AddTicks(8770), "Chennai", 109.99m, "Vistara2929", "Hyderabad", 0, 38, 170 },
                    { 30, "Boeing 737 MAX", "Air India", new DateTime(2025, 6, 8, 11, 35, 48, 749, DateTimeKind.Utc).AddTicks(8773), 40, 175, 359.99m, new DateTime(2025, 6, 8, 8, 35, 48, 749, DateTimeKind.Utc).AddTicks(8772), "Kolkata", 139.99m, "AI3030", "Chennai", 0, 40, 175 },
                    { 31, "Airbus A320", "SpiceJet", new DateTime(2025, 6, 9, 10, 35, 48, 749, DateTimeKind.Utc).AddTicks(8775), 35, 160, 369.99m, new DateTime(2025, 6, 9, 8, 35, 48, 749, DateTimeKind.Utc).AddTicks(8775), "Delhi", 149.99m, "SG3131", "Kolkata", 0, 35, 160 },
                    { 32, "Airbus A321", "IndiGo", new DateTime(2025, 6, 10, 10, 35, 48, 749, DateTimeKind.Utc).AddTicks(8778), 40, 180, 399.99m, new DateTime(2025, 6, 10, 8, 35, 48, 749, DateTimeKind.Utc).AddTicks(8777), "Goa", 159.99m, "6E3232", "Delhi", 0, 40, 180 },
                    { 33, "ATR 72", "Vistara", new DateTime(2025, 6, 11, 9, 35, 48, 749, DateTimeKind.Utc).AddTicks(8780), 30, 150, 299.99m, new DateTime(2025, 6, 11, 8, 35, 48, 749, DateTimeKind.Utc).AddTicks(8780), "Pune", 109.99m, "Vistara3333", "Goa", 0, 30, 150 },
                    { 34, "Boeing 737", "Air India", new DateTime(2025, 6, 12, 10, 35, 48, 749, DateTimeKind.Utc).AddTicks(8911), 35, 160, 329.99m, new DateTime(2025, 6, 12, 8, 35, 48, 749, DateTimeKind.Utc).AddTicks(8910), "Ahmedabad", 119.99m, "AI3434", "Pune", 0, 35, 160 },
                    { 35, "Airbus A320", "SpiceJet", new DateTime(2025, 6, 13, 9, 35, 48, 749, DateTimeKind.Utc).AddTicks(8915), 38, 170, 339.99m, new DateTime(2025, 6, 13, 8, 35, 48, 749, DateTimeKind.Utc).AddTicks(8914), "Jaipur", 129.99m, "SG3535", "Ahmedabad", 0, 38, 170 }
                });

            migrationBuilder.InsertData(
                table: "Users",
                columns: new[] { "Id", "CreatedAt", "Email", "FirstName", "LastName", "Password", "PhoneNumber", "Role" },
                values: new object[] { 1, new DateTime(2025, 5, 30, 8, 35, 48, 749, DateTimeKind.Utc).AddTicks(8037), "aster@gmail.com", "System", "Administrator", "$2a$11$swccSq1N1BM/zY.Yfc819uizjByUOPCvPZOzD1qXrC6BucGr1btie", "+1234567890", 1 });

            migrationBuilder.CreateIndex(
                name: "IX_Passengers_ReservationId",
                table: "Passengers",
                column: "ReservationId");

            migrationBuilder.CreateIndex(
                name: "IX_Payments_ReservationId",
                table: "Payments",
                column: "ReservationId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Reservations_FlightId",
                table: "Reservations",
                column: "FlightId");

            migrationBuilder.CreateIndex(
                name: "IX_Reservations_UserId",
                table: "Reservations",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_Users_Email",
                table: "Users",
                column: "Email",
                unique: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "LoginLogs");

            migrationBuilder.DropTable(
                name: "Passengers");

            migrationBuilder.DropTable(
                name: "Payments");

            migrationBuilder.DropTable(
                name: "RegistrationLogs");

            migrationBuilder.DropTable(
                name: "Reservations");

            migrationBuilder.DropTable(
                name: "Flights");

            migrationBuilder.DropTable(
                name: "Users");
        }
    }
}
